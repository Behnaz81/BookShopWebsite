<?php

//Connecting to database
$connection = mysqli_connect("localhost", "root", "", "bookshop");

session_start();
